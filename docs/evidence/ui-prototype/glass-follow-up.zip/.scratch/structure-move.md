# Structure move — launcher-ui prototype (2026-10-02)

Branch `prototype/launcher-ui`, worktree `pane-ui-prototype`. Behavior-
preserving relocation only, per the accepted structure in main's
`docs/ui-rework-interview.md` ("folder structure agreed"). No commits made.

## Move map

| Old (crates/pane/src) | New | Changes beyond location |
| --- | --- | --- |
| `lib.rs` lines 219–836 (`LauncherWindow`, `ScrolledFor`, `impl LauncherWindow`, `impl Render`, `KEY_CONTEXT`) | `app.rs` (verbatim) | new module header/imports; `KEY_CONTEXT` now `pub(crate)` (lib.rs `bind_keys` reads it) |
| `lib.rs` lines 1–217 remainder | `lib.rs` (rewritten) | entry points + re-exports; `bind_keys` paths updated to `extension_views::…` / `features::root_search` |
| `root_search.rs` | `features/root_search/mod.rs` | imports: `crate::app::LauncherWindow`, `crate::extension_views::form::TextEditingKeys` (+ one doc-link update) |
| `form.rs` | `extension_views/form.rs` | import: `crate::app::LauncherWindow` |
| `custom_view.rs` | `extension_views/custom_view.rs` | import: `crate::app::LauncherWindow` |
| (new) | `features/mod.rs` | `pub(crate) mod root_search;` |
| (new) | `extension_views/mod.rs` | `pub(crate) mod custom_view; pub(crate) mod form;` |

`links.rs`, `main.rs`, `Cargo*`, `tests/`, `assets/`, `pane-core`: untouched.
No `ui/` created (later worker). `git mv` used for the three files (renames
staged, not committed).

## Public API preserved (root re-exports unchanged)

`pane::{LauncherWindow, SystemLinks, bind_keys, APP_VERSION, sample_commands,
default_extensions, cache_dir, data_dir}` plus the `actions!` set
(`SelectNext`, `SelectPrevious`, `Confirm`, `Back`, `FocusNext`,
`FocusPrevious`) — `main.rs` and `tests/` need no edits. `LauncherWindow`'s
pub methods, IDs/debug selectors, key contexts/actions, focus, subscriptions
and row a11y semantics are byte-identical moved code.

## Visibility notes

`features`/`extension_views` are private crate-root modules with `pub(crate)`
children — same crate-internal visibility as before for their items. The
sibling `impl LauncherWindow` blocks (root search, form, custom view) now
live outside `app`, so the items they access had to become `pub(crate)`:
fields `launcher`, `focus_handle`, `query`, `form`, `custom_view`, method
`show_until_done`, and `KEY_CONTEXT`. All other fields (`scroll`,
`scrolled_for`, `scroll_again`, `drawn`), the `ScrolledFor` type and the
remaining methods stay private. No public field or fn changes; external API
unchanged. (An earlier draft of this note claimed `KEY_CONTEXT` was the only
widening — that was wrong: the first `cargo check` failed with 39 privacy
errors, fixed by the `pub(crate)` set above.)

## Verification status

`cargo fmt -p pane --check` clean. `cargo check -p pane` green and
`cargo check -p pane --tests` green (shared target dir
`C:/Users/ADMIN/Desktop/nguyenvu/pane/target`) — log:
`.scratch/check-structure-green.log`. Run verification (the window tests) is
deferred to main.

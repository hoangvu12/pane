# UI review gaps — what the window tests will NOT catch (2026-10-02)

Read-only preparation for reviewing the shared-ui integration (worker
642df52f) in the launcher first proof. Sources inspected: `crates/pane/tests/
window.rs` (1305 lines), `tests/command_search.rs` (149), `src/app.rs`
render path, `features/root_search/mod.rs`, `extension_views/{form,
custom_view}.rs`. No source edits, no builds.

## What tests already pin (the preservation floor)

Selectors asserted by debug_bounds: `row-<title>`,
`unavailable-reason-<title>`, `status-{idle,running,progress,result,error}`,
`field-<id>`, `field-error-<id>`, `choice-<field>-<choice>`, `submit`,
`no-results`, `rows`, `custom-view`, `detail-<line>`, and element id
`search`. ARIA trees (JSON): EditableComboBox "Search" (value+placeholder),
ListBox/ListBoxOption with focus following the selection, form
TextInput/RadioGroup/RadioButton/Button labels-values-errors, ColorWell.
Focus flows (query focus, tab order, rejected-field focus), IME (root +
form), resizes 640x420 and 640x**200** (height only), scroll-into-view,
wheel, Enter/Escape, no-results, calculator/app/quicklink runs. All
these areas have regression coverage, with the gaps below. Passing tests
does not establish complete behavior preservation or native visual fidelity.

## Gaps: important, untested, plausible to break in a visual pass

1. **Narrow window.** Every test resize keeps width 640 (640x420, 640x200).
   Nothing narrows the window, and no test asserts any element stays inside
   the window bounds. A restyled panel with larger padding, a taller search
   field, or row keycaps can overflow horizontally unseen. Validate:
   resize to ~380x420 (native or a targeted test) and check `search`,
   `rows`, `row-<title>`, `status` bounds all fit the window; also the
   40%-details scroll case (`detail-<line>` inside `details`) at narrow
   width.
2. **Long title + unavailable reason.** The unavailable test (window.rs:226)
   asserts that the row and reason fit vertically within the list through
   `row_is_visible`, using short sample titles. That helper checks top and
   bottom only; it does not check horizontal containment or long-text
   wrapping. No test in the inspected scenarios
   uses a long command title. The heading element `div().text_xl().child(
   view.title)` (app.rs:614) has **no id/debug selector** — it is invisible
   to every test, so "proper title shrinking" (main's ask) is entirely
   unverified: a wrap or clip that eats the list/status cannot fail a test.
   Validate natively: ~120-char command title on a command screen + long
   unavailable reason in a row; if a test is wanted later, give the heading
   a debug selector first.
3. **Status text overflow.** Status assertions are presence-only
   (`status-result`/`status-error` `is_some`) with short strings. Long
   errors (preview failures, crash reports) currently wrap; a restyled
   single-line status with truncation can hide the message, and wrapping
   changes the strip's height (shrinking the flex-1 list above) with no
   test noticing. Validate: trigger a long Status::Error natively; check
   the status stays readable and the list stays usable.
4. **Light theme form control contrast.** Tests contain zero color
   assertions (by design — behavior/ARIA only). Form control colors, row
   selection tint, status colors and the ◉/○ choice glyphs move to theme
   tokens in this change; "light must work now" has no mechanical check and
   GLM workers have no vision. Validate natively: switch to light (env/CLI
   per the interview log), open the form ("Greet someone"), and judge field
   bg/border/focus ring, chosen radio, submit button, `field-error-<id>`
   text, row selection and status colors against the light panel.
5. **Root vs non-root heading/layout.** One render path draws every screen:
   heading, body, status. No test asserts the heading's presence or absence
   per screen, or any root-specific layout. If the integration gives root
   search a distinct treatment (reference: search-first, no visible
   heading) nothing verifies it — and nothing stops the heading silently
   disappearing from command screens. Validate natively side-by-side: root
   (query field first) vs a command screen (heading + list) vs command
   search (field + list, per command_search.rs) — plus `search` +
   `row-<title>` still present in each.

## Constraint worth repeating for review

Inputs/ARIA/selectors above are the integration floor; color and visual
fidelity are main's judgment only. Suggested order: narrow-window and
long-title checks first (layout breakage), then light-theme contrast, then
root/non-root layout comparison.

# Main review notes — integration in progress

These are observations of work in progress, to recheck on the completed slice.

- `ui/mod.rs`: `configure` currently calls `load_fonts(cx)?` before setting
  visuals. If fonts fail and the caller continues, requested light/opaque
  silently becomes default dark/glass. Apply configuration independently of
  font-loading success. Process-wide defaults also mean setting PANE_THEME
  for existing tests does not exercise light: tests never call configure.
- `result_row.rs`: fixed nonshrinking reason up to 280px plus icon28,
  padding20 and multiple 12px gaps can exceed a 380px outer window before
  title/subtitle take any width. Consider placing unavailable reason below
  the inline title/subtitle within one flexible text group. Verify actual
  native narrow render. Two growing inline text nodes plus spacer may also
  push subtitle far from title compared with reference.
- Hiding native titlebar removes its drag area. Preserve a drag region
  outside the editable query (search icon/padding, nonroot heading) if the
  final integration has none. Pinned GPUI supports
  `window_control_area(WindowControlArea::Drag)` and `start_window_move`.
- Material docs must distinguish dark tint 0.7 from derived light tint;
  no universal contrast guarantee. Unsupported platform normalization was
  fixed in the current material source.

Existing unavailable-row tests check vertical containment, not just presence;
they do not check horizontal bounds or long-text wrapping. Main corrected
the side-chat coverage report accordingly.

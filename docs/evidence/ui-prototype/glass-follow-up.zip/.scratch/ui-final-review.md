# UI final review — launcher prototype vs 748d71e (2026-10-02, read-only)

Read-only review of the implemented prototype (app.rs, ui/, main.rs/lib.rs
diffs, moved features/extension_views; untracked files read explicitly,
baseline `git show 748d71e:...`). Main decides and fixes. Two concrete
findings; the hint areas below verified clean.

Resolution: both findings were corrected. Main inspected final native
captures showing wrapped errors at 380x420 and the enlarged drag target
preserves the query's position. The new regression test verifies footer
wrapping, growth, height limits, wheel scrolling to the last line, and
returning to the first. All 51 tests pass. Findings below remain as the
review history, not unresolved defects.

## Findings (prioritized)

Main's native confirmation: at 380x420, the sample's validation error is
one unwrapped line clipped at the right edge. The direct text child in a
flex row needs an explicit wrapping container as well as a flexible footer
height. Evidence: `native-review/dark-opaque-narrow-flow/run-20261002-062920-8ae3aad9/03-after-DOWN-2-ENTER-window.png`.

1. **Long status text is clipped by the fixed 50px footer** (correctness).
   `ui/material.rs` `Material::footer` builds `.flex_none().flex().items_
   center().h(theme.geometry.footer_height)` with `footer_height = px(50.)`
   (`ui/theme.rs` `Geometry::shared`); `app.rs` render tail puts
   `status_text` in it with no truncation or overflow handling. Baseline
   (`748d71e:crates/pane/src/lib.rs` status element): auto-height div — long
   text wrapped and the flex-1 body shrank, so the whole message stayed
   readable. Consequence: real `Status::Error` / `Status::Progress` strings
   (folder-picker failures, npm/Git download errors, pausing and runtime
   errors — all land in this line) wrap to 3+ lines at 12.5px ≈ over 50px,
   overflow the fixed strip and are clipped at the window edge (the panel
   paints `overflow_hidden`), losing the tail of runtime feedback. The 50
   passing tests can't catch it: status assertions are presence-only with
   short strings (my earlier gap report, `.scratch/ui-review-gaps.md`).

2. **Root search's only window-drag region is the ~20px magnifier glyph**
   (functional regression vs baseline). `features/root_search/mod.rs`
   `render_search`: the drag region is the magnifier's wrapper —
   `.window_control_area(WindowControlArea::Drag).flex_none().child(glyph(
   Glyph::Search, px(20.), …))` — and it is the only one on the root screen;
   the heading that carries `WindowControlArea::Drag` on every other screen
   is `None` for `Screen::Root` (`app.rs` heading match). Baseline: a native
   title bar (not `appears_transparent`), draggable across its full width on
   every screen. Consequence: on the launcher's primary screen the window
   can be moved only by discovering a 20px icon (plus resize borders); if
   the tiny target is unintended, the whole search header outside the
   editable field is the natural drag area. (If the platform's transparent
   title bar still drags natively, this is macOS-only or moot — main can
   judge on the native build.)

## Verified clean (hint areas)

- **Global config initialization**: `ui/mod.rs` — `static VISUALS:
  OnceLock<Visuals>` is immutable once set; `main.rs` calls
  `pane::configure_visuals` before the first window (correct order); tests
  never configure and get the documented dark/glass defaults;
  `Material::new` normalizes glass→opaque on frost-less platforms. No
  mutable global, no re-read of the environment.
- **Row/scroll/a11y preservation**: `app.rs` `render_row` keeps
  `.id(("row", index))`, `row-<title>` debug selector, `Role::ListBoxOption`,
  `aria_label/selected/active_descendant/disabled` and the combined
  subtitle+reason `aria_description`; `result_row.rs` keeps the
  `unavailable-reason-<title>` debug convention, wraps (never truncates)
  the reason and lets the row grow past its 44px floor. The list keeps
  `overflow_y_scroll().track_scroll(&self.scroll)` and
  `keep_selected_visible`/`ScrolledFor` is byte-identical to baseline.
- **Field focus readability**: form text field, choice group, submit button
  and custom view all keep `.focus(|…| …border_color(theme.focus_ring))`
  (was `0x8ab4f8`), with themed caret/selection/marked/placeholder colors
  on both the query and form fields (`extension_views/form.rs`,
  `custom_view.rs`, `features/root_search/mod.rs` diffs).
- Public API: `LauncherWindow`, `bind_keys`, `sample_commands`,
  `default_extensions`, `cache_dir`, `data_dir`, `APP_VERSION`,
  `SystemLinks` unchanged; `configure_visuals`/`window_background` are the
  only new exports, both required by the accepted env-switch and
  `WindowOptions::window_background` seams.

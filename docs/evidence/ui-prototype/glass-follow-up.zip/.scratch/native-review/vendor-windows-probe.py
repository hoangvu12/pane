"""Materialize only the pinned Windows crate, preserving pinned GPUI identities."""
from pathlib import Path
import json
import shutil
import tomllib

root = Path('C:/Users/ADMIN/Desktop/nguyenvu/pane-ui-prototype')
upstream = Path('C:/Users/ADMIN/.cargo/git/checkouts/gpui-ce-866ba02453e968cb/17d9c8e')
target = root / 'vendor/gpui_windows'
if target.exists():
    raise SystemExit('Refusing to overwrite existing vendor directory')
shutil.copytree(upstream / 'crates/gpui_windows', target)
workspace = tomllib.loads((upstream / 'Cargo.toml').read_text())['workspace']
manifest = tomllib.loads((target / 'Cargo.toml').read_text())
git = 'https://github.com/gpui-ce/gpui-ce'
rev = '17d9c8e8fdb30a329d817ca06bff424e8e848f1a'
for key, value in list(manifest['package'].items()):
    if isinstance(value, dict) and value.get('workspace'):
        manifest['package'][key] = workspace['package'][key]
manifest.pop('lints', None)
def dependencies(deps):
    for name, value in list(deps.items()):
        if isinstance(value, dict) and value.get('workspace'):
            base = workspace['dependencies'][name]
            base = {'version': base} if isinstance(base, str) else dict(base)
            for key, item in value.items():
                if key == 'workspace': continue
                base[key] = base.get(key, []) + item if key == 'features' else item
            value = base
        if isinstance(value, dict) and 'path' in value:
            value = dict(value)
            value.pop('path')
            value.update(git=git, rev=rev)
        deps[name] = value
dependencies(manifest['dependencies'])
for item in manifest.get('target', {}).values():
    dependencies(item['dependencies'])
def toml(value):
    if isinstance(value, str): return json.dumps(value)
    if isinstance(value, bool): return str(value).lower()
    if isinstance(value, list): return '[' + ', '.join(map(toml, value)) + ']'
    if isinstance(value, dict): return '{ ' + ', '.join(json.dumps(k)+' = '+toml(v) for k,v in value.items()) + ' }'
    return str(value)
lines=[]
for name in ('package','lib','features','dependencies'):
    lines += ['['+name+']']+[k+' = '+toml(v) for k,v in manifest[name].items()]+['']
for condition, item in manifest['target'].items():
    lines += ['[target.'+json.dumps(condition)+'.dependencies]']+[k+' = '+toml(v) for k,v in item['dependencies'].items()]+['']
lines += ['[workspace]']
(target / 'Cargo.toml').write_text('\n'.join(lines)+'\n')
renderer = target / 'src/directx_renderer.rs'
source = renderer.read_text()
needle = 'desc.RenderTarget[0].DestBlendAlpha = D3D11_BLEND_ONE;'
assert source.count(needle) == 2
renderer.write_text(source.replace(needle, '// Preserve source-over alpha through translucent layers.\n    desc.RenderTarget[0].DestBlendAlpha = D3D11_BLEND_INV_SRC_ALPHA;'))
print('Prepared gpui_ce_windows with two source-over alpha corrections')

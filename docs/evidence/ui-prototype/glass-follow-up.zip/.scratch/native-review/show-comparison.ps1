﻿Add-Type -AssemblyName System.Windows.Forms, System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()
$form = New-Object System.Windows.Forms.Form
$form.Text = 'Pane — Dark and Light native captures'
$form.StartPosition = 'CenterScreen'
$form.BackColor = [System.Drawing.Color]::FromArgb(36,36,36)
$area = [System.Windows.Forms.Screen]::PrimaryScreen.WorkingArea
$form.ClientSize = New-Object System.Drawing.Size ([Math]::Min(1570, $area.Width - 60)), ([Math]::Min(540, $area.Height - 80))
$grid = New-Object System.Windows.Forms.TableLayoutPanel
$grid.Dock = 'Fill'
$grid.ColumnCount = 2
$grid.RowCount = 2
$grid.Padding = New-Object System.Windows.Forms.Padding 12
[void]$grid.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle 'Percent',50))
[void]$grid.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle 'Percent',50))
[void]$grid.RowStyles.Add((New-Object System.Windows.Forms.RowStyle 'Absolute',36))
[void]$grid.RowStyles.Add((New-Object System.Windows.Forms.RowStyle 'Percent',100))
$images = @()
for ($i = 0; $i -lt 2; $i++) {
    $name = @('Dark','Light')[$i]
    $label = New-Object System.Windows.Forms.Label
    $label.Text = $name
    $label.Dock = 'Fill'
    $label.ForeColor = [System.Drawing.Color]::White
    $label.Font = New-Object System.Drawing.Font 'Segoe UI',14
    $grid.Controls.Add($label,$i,0)
    $picture = New-Object System.Windows.Forms.PictureBox
    $picture.Dock = 'Fill'
    $picture.SizeMode = 'Zoom'
    $picture.Margin = New-Object System.Windows.Forms.Padding 5
    $capture = [System.Drawing.Image]::FromFile("C:/Users/ADMIN/Desktop/nguyenvu/pane-ui-prototype/docs/ui-prototype/$($name.ToLower()).png")
    $images += $capture
    $picture.Image = $capture
    $grid.Controls.Add($picture,$i,1)
}
$form.Controls.Add($grid)
try { [void]$form.ShowDialog() } finally { $form.Dispose(); foreach ($capture in $images) { $capture.Dispose() } }

# Diagnostic only; caller supplies its OWN spawned HWND. Never targets other apps.
Add-Type @'
using System;
using System.Runtime.InteropServices;
public static class FrostProbe {
 [StructLayout(LayoutKind.Sequential)] public struct Margins { public int L,R,T,B; }
 [StructLayout(LayoutKind.Sequential)] public struct Accent { public int State,Flags,Color,Animation; }
 [StructLayout(LayoutKind.Sequential)] public struct Data { public int Attribute; public IntPtr Ptr; public int Size; }
 [DllImport("dwmapi.dll")] public static extern int DwmExtendFrameIntoClientArea(IntPtr hwnd, ref Margins margins);
 [DllImport("dwmapi.dll")] public static extern int DwmSetWindowAttribute(IntPtr hwnd, int attribute, ref int value, int size);
 [DllImport("user32.dll")] public static extern int SetWindowCompositionAttribute(IntPtr hwnd, ref Data data);
 [DllImport("user32.dll", EntryPoint="GetWindowLongPtrW")] public static extern IntPtr GetWindowLongPtr(IntPtr hwnd, int index);
 public static int SetAccent(IntPtr hwnd, int state) {
  Accent a = new Accent {State=state, Flags=0, Color=0x01000000};
  IntPtr p=Marshal.AllocHGlobal(Marshal.SizeOf(a));
  try { Marshal.StructureToPtr(a,p,false); Data d=new Data {Attribute=19,Ptr=p,Size=Marshal.SizeOf(a)}; return SetWindowCompositionAttribute(hwnd,ref d); }
  finally { Marshal.FreeHGlobal(p); }
 }
}
'@
switch ($env:PANE_FROST_PROBE) {
 'transparent' { Write-Host "[frost-probe] Transparent result=$([FrostProbe]::SetAccent($hwnd,2))" }
 'none' { Write-Host "[frost-probe] None result=$([FrostProbe]::SetAccent($hwnd,0))" }
 'extend' { $m = New-Object FrostProbe+Margins; $m.L=-1; $m.R=-1; $m.T=-1; $m.B=-1; Write-Host "[frost-probe] Extend HRESULT=$([FrostProbe]::DwmExtendFrameIntoClientArea($hwnd,[ref]$m))" }
 'accent3' { Write-Host "[frost-probe] Accent3 result=$([FrostProbe]::SetAccent($hwnd,3))" }
 'acrylic' { Write-Host "[frost-probe] Accent reset=$([FrostProbe]::SetAccent($hwnd,0))"; $v=3; Write-Host "[frost-probe] Acrylic HRESULT=$([FrostProbe]::DwmSetWindowAttribute($hwnd,38,[ref]$v,4))" }
}
Write-Host "[frost-probe] extendedStyle=$([FrostProbe]::GetWindowLongPtr($hwnd,-20).ToInt64().ToString('x'))"
[void][PaneWin]::SetWindowPos($hwnd, [IntPtr](-1), 0, 0, 0, 0, 0x13)

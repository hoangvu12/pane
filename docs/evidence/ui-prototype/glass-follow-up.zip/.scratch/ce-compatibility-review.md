# CE component fork — compatibility probe report

Date: 2026-10-02. Worker: implementation worker (GLM), branch
`prototype/launcher-ui` worktree. Owner of this probe:
`.scratch/ce-compat/**` and this file. No adoption decision is made here —
evidence only, for orchestrator review.

## Question

Can the GPUI CE component fork (`github.com/gpui-ce/gpui-component`, git rev
`c082069`, the fork's current main; published layers are 0.2.0) compile
against **Pane's pinned renderer** `gpui-ce` git rev
`17d9c8e8fdb30a329d817ca06bff424e8e848f1a` (post-WGPU-migration, 2026-09-26)
with all GPUI sources aligned to that one rev — no renderer downgrade?

Prior raw evidence (kept, referenced): `.scratch/check-ce-base.log`
(published 0.2.0: `runtime_shaders` feature resolution failure),
`.scratch/check-ce-base-git.log` (fork git c082069, unpatched: 25 errors),
`.scratch/toolkit-findings.md` (summary + WGPU migration commit lineage).

## Method

- Isolated copy of the fork at `.scratch/ce-compat/gpui-component-c082069`
  (cloned from `https://github.com/gpui-ce/gpui-component`, HEAD verified
  `c08206932417f863062d2ab70cc2854c6ca04238`, clean tree before edits; `.git`
  kept so `git diff` is the portable patch). No shared cargo checkout was
  mutated; the copy is a plain directory clone.
- Two independent probe crates (NOT part of the Pane workspace; each carries
  an empty `[workspace]` table to detach from the repo-root workspace):
  `probe-base/` (path-deps `gpui_ce_components_base`) and `probe-component/`
  (path-deps `gpui_ce_components`).
- Both probes carry `[patch.crates-io]` redirecting `gpui-ce`,
  `gpui_ce_macros`, `gpui_ce_platform`, `gpui_ce_web` to the pinned git rev.
  The fork's workspace itself still declares crates.io sources; the patch
  aligns the resolved graph to one GPUI source identity.
- `CARGO_TARGET_DIR=C:/Users/ADMIN/Desktop/nguyenvu/pane/target` reused.
- Patch policy: only the observed mechanical categories —
  1. `use gpui::AppContext as _;` imports (App::notify moved to the
     `AppContext` trait),
  2. `PaintQuad` `border_dashed_length`/`border_dashed_gap` fields
     (solid defaults),
  3. Hsla → `Background` via `.into()`.
  Further errors were discovered only through the compiler; the styled layer
  received the same two mechanical categories where they occurred
  (attachment.rs imports; window_border.rs/dialog.rs `.into()`), which is
  noted per-file in the split patches.

## Result 1 — Base layer: COMPILES

`gpui_ce_components_base` 0.2.0 (fork c082069, minimally patched, path dep)
against pinned `gpui-ce` 17d9c8e8: `cargo check` **exit 0**.
Log: `logs/probe-base-check.log` (2m22s). 3 pre-existing warnings
(unused `ev` variables in `resizable/resize_handle.rs`), no errors.
`cargo tree -i gpui-ce`: single gpui-ce node at the pinned rev, depended on
by the patched Base. Metadata: `logs/probe-base-metadata.json`.

### Base patch (9 files, +18/−2 lines; `logs/base-compat.patch`)

| Category | Count | Files |
| --- | --- | --- |
| `use gpui::AppContext as _;` import | 8 imports covering 19 call sites | popover.rs, input/base/element.rs, plot/element.rs, scroll_bounce.rs, scrollable_mask.rs, scrollbar.rs, text/inline.rs, text/inline_object.rs |
| PaintQuad dashed fields `border_dashed_length: 2.0, border_dashed_gap: 1.0` | 4 initializers | scrollable_mask.rs, scrollbar.rs, selectable_text.rs, text/inline.rs |
| `transparent_black()` → `transparent_black().into()` (Hsla→Background) | 2 sites | selectable_text.rs, text/inline.rs |

## Result 2 — Styled Components layer: 6 errors remain (3 new categories)

`gpui_ce_components` 0.2.0 (fork c082069, minimally patched) — progression:

1. `logs/probe-component-check.log`: 12 errors.
2. After the same AppContext-import category applied to
   `component/src/attachment.rs` (2 notify sites):
   `logs/probe-component-check2.log`: 10 errors.
3. After the same Hsla→Background `.into()` category applied to
   `component/src/window_border.rs` (2) and `component/src/dialog/dialog.rs`
   (2): `logs/probe-component-check3.log`: **6 errors, exit 101**.

### Remaining 6 errors (all beyond the sanctioned mechanical categories)

| Category | Sites | Detail |
| --- | --- | --- |
| `E0034` multiple applicable items | time/date_picker.rs:711, tab/tab_bar.rs:531 | `.on_prepaint` is defined BOTH in the fork's `gpui_base::ElementExt` AND in the pinned rev's `StatefulInteractiveElement`/`Interactivity` (div.rs:853/1932). Resolving needs an explicit trait disambiguation with a semantic choice of which implementation to keep. |
| `E0599` `Deferred::with_priority` gone | touch_selection/edit_menu.rs:154, touch_selection/handle.rs:187, menu/context_menu.rs:200 | The pinned rev's Deferred API is `.priority(impl Into<DeferredPriority>)` / `.priority_auto()` (elements/deferred.rs:89/97). The fork's `POPUP_PRIORITY: usize = 100` (base/src/popup.rs:15) would map to `.priority(100)`; base's own popup.rs:198 already uses the new API — these 3 component sites simply were not migrated. A port, not an import. |
| `E0599` `App::asset_source` gone | native_menu/mod.rs:214 (macos+windows branches) | No `asset_source` method on `App` in the pinned rev (only on test contexts: bench/headless/test_app/visual_test_context). Needs porting to however the pinned rev exposes the asset source. |

### Component patch (3 files, +5/−4 lines; `logs/component-compat.patch`)

attachment.rs (+1 import), window_border.rs (2× `.into()`), dialog/dialog.rs
(2× `.into()`). Base patch and component patch are split so the Base
evidence stands alone.

## Semantic review of the mechanical patches

- **AppContext imports:** pre-migration `App::notify(view_id)` was an
  inherent method; in the pinned rev it is provided by the `AppContext`
  trait (implemented by App; rustc's own help proposes exactly this import).
  Same name, same argument, same redraw effect — a scope fix, not a behavior
  change. `as _` avoids name collisions (test modules import it under
  aliases).
- **PaintQuad dashed fields:** all 4 initializers set
  `border_style: BorderStyle::default()` (Solid). Dashing applies only to
  `BorderStyle::Dashed`, so the added values are inert; they mirror the
  renderer's own helpers `window::quad/fill/outline`
  (`DEFAULT_BORDER_DASHED_LENGTH = 2.0`, `DEFAULT_BORDER_DASHED_GAP = 1.0`,
  scene.rs:32-33). Literals are used because those consts are `pub(crate)`
  in the renderer. No visual change for solid borders.
- **Hsla→Background `.into()`:** `From<Hsla> for Background` exists in the
  pinned rev (rustc help proposes `.into()`); same color, new wrapper type.
  Affects `PaintQuad::border_color` and `BoxShadow::color` fields.

## Source identity (cargo metadata evidence)

`logs/probe-base-metadata.json`, `logs/probe-component-metadata.json`,
`logs/probe-component-tree.txt`:

- Every gpui-ce-family package resolves to the SINGLE pinned git rev
  `17d9c8e8…`: gpui-ce 0.2.2, gpui_ce_collections 0.2.2,
  gpui_ce_derive_refineable 0.2.2, gpui_ce_macros 0.1.0,
  gpui_ce_refineable 0.2.2, gpui_ce_scheduler 0.2.2,
  gpui_ce_shared_string 0.1.0, gpui_ce_sum_tree 0.2.2, gpui_ce_util 0.2.6.
  No crates.io gpui-ce, no second GPUI source, no renderer downgrade.
- Fork packages are local PATH nodes (the patched copy).
- Caveats that remain even with alignment:
  - `zed-sum-tree 0.2.0` comes from crates.io (fork's `sum-tree` workspace
    dep) alongside the pinned rev's own `gpui_ce_sum_tree` — two sum-tree
    implementations in one graph (distinct crate names, so it resolves, but
    duplicate code and a source-identity wart).
  - The component graph also pulls crates.io `reqwest 0.13.5` and the full
    Base leaf set (markdown, syntect, html5ever, lsp-types, ropey, resvg,
    usvg, image, rust-embed, rust-i18n, chrono, regex, aho-corasick,
    palette, schemars…; 616 packages locked for the component probe).
  - `gpui_ce_platform`/`gpui_ce_web` patches are unused warnings in these
    probes (neither layer's check graph pulls them; `gpui_ce_platform`
    enters only via dev-deps / the kit umbrella / assets features).
    On Windows the fork's platform features (font-kit/x11/wayland) exist in
    the pinned rev, so no feature mismatch there.

## Commands (exact)

See `.scratch/ce-compat/probe-base/commands.txt` and
`.scratch/ce-compat/probe-component/commands.txt`. Essential form:

    cd .scratch/ce-compat/probe-base
    CARGO_TARGET_DIR=C:/Users/ADMIN/Desktop/nguyenvu/pane/target cargo check

    cd .scratch/ce-compat/probe-component
    CARGO_TARGET_DIR=C:/Users/ADMIN/Desktop/nguyenvu/pane/target cargo check

Patches regenerated with `git diff` inside the isolated copy:

    cd .scratch/ce-compat/gpui-component-c082069
    git diff -- crates/base      > ../logs/base-compat.patch      (137 lines)
    git diff -- crates/component > ../logs/component-compat.patch (54 lines)

## Application tree drift

This probe touched **only** `.scratch/ce-compat/**`, the probe crates inside
it, and `.scratch/ce-compatibility-review.md`. No application manifests,
no lockfile, no application source. The app `Cargo.toml`,
`crates/pane/Cargo.toml` and `Cargo.lock` are byte-identical to the branch
state before this probe (git shows no modification to them).

Note: while this probe ran, a concurrent worker began restructuring
application sources in this same worktree (renames to
`crates/pane/src/extension_views/` and `features/root_search/`, a new
`app.rs`, `lib.rs` edits). Those changes are not this probe's; it neither
made nor reviewed them. The probes carry their own `Cargo.lock` files
inside `.scratch/ce-compat/probe-*/` and are detached from the Pane
workspace (empty `[workspace]` tables).

## Honest limitations

- Windows only. No macOS/Linux compilation evidence in this session; the
  probe graph includes platform-specific crates but `cargo check` ran on
  Windows for the host target only.
- `cargo check`, not a full `cargo build` (codegen/asm/link not exercised)
  and not `cargo test` (dev-deps and test modules not compiled; the fork's
  own test code was not patched and may fail separately).
- Runtime behavior (actually running a fork component in a window against
  the pinned rev) is untested — this is compile-level compatibility only.
- The 6 remaining component errors were characterized from rustc output and
  focused source reads; no attempt was made to fix them (out of the probe's
  bounded scope).

## Files

- `.scratch/ce-compat/gpui-component-c082069/` — isolated patched fork copy
  (git HEAD c08206932417f863062d2ab70cc2854c6ca04238).
- `.scratch/ce-compat/probe-base/`, `probe-component/` — probe crates.
- `.scratch/ce-compat/logs/` — all logs, patches, metadata, tree output.
- This report: `.scratch/ce-compatibility-review.md`.
